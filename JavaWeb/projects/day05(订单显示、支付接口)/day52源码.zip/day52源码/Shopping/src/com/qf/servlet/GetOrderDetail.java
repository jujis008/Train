package com.qf.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.dao.impl.OrderDaoImpl;
import com.qf.entry.Address;
import com.qf.entry.BuyGoods;
import com.qf.entry.Order;
import com.qf.entry.OrderDetail;
import com.qf.entry.User;
import com.qf.service.impl.OrderServiceImpl;
import com.qf.service.impl.UserServiceImpl;
import com.qf.utils.StrUtils;
//�鿴��������
@WebServlet("/getOrderDetail")
public class GetOrderDetail extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User user = (User)req.getSession().getAttribute("user");
		if(user!=null){
			String oid = req.getParameter("oid");
			if(StrUtils.empty(oid)){
				//��ȡ���� order ���ݶ������ ��ȡ������Ϣ
				Order order = new OrderServiceImpl().getSingle(oid);
				//��ȡ��ַ ����order id -->aid-->address��ѯ�ջ�����Ϣ
				Address address = new UserServiceImpl().getSingleA(order.getAid());
				//��ȡ�����������Ʒ��Ϣ
				List<BuyGoods> list = new OrderServiceImpl().getDetail(oid);
				req.setAttribute("od", new OrderDetail(order, address, list));
				req.getRequestDispatcher("orderDetail.jsp").forward(req, resp);
			}
		}else{
			resp.sendRedirect("login.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
