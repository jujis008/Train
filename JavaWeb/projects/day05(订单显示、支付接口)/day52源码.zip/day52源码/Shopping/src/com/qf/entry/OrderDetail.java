package com.qf.entry;

import java.util.List;

//��� ���� ��ϸ��Ϣ ʵ��
//order�� address��  orderdetail��goods��ͨ��pid������ȡ��������
public class OrderDetail {
	private Order order;
	private Address address;
	private List<BuyGoods> list;
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public List<BuyGoods> getList() {
		return list;
	}
	public void setList(List<BuyGoods> list) {
		this.list = list;
	}
	public OrderDetail(Order order, Address address, List<BuyGoods> list) {
		super();
		this.order = order;
		this.address = address;
		this.list = list;
	}
	public OrderDetail() {
		super();
	}
	
}
