package com.qf.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.User;
import com.qf.service.UserService;
import com.qf.service.impl.UserServiceImpl;
import com.qf.utils.EmailUtils;
import com.qf.utils.MD5Utils;
import com.qf.utils.RandomUtils;

public class UserRegister extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String email = req.getParameter("email");
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String gender = req.getParameter("gender");
		UserService service = new UserServiceImpl();
		//flag 0��δ���� role 1����ͨ�û� 0�ǹ���Ա
		User user = new User(0, 1, username, MD5Utils.md5(password), email, gender, RandomUtils.createActiveCode());
		if(service.add(user)){
			req.getSession().setAttribute("registerUser", user);
			//���ͼ����ʼ�
			EmailUtils.sendEmail(user);
			//����ע��ɹ�ҳ��
			resp.sendRedirect("registerSuccess.jsp");
		}else{
			req.getSession().setAttribute("msg", "��,�����쳣 ע��ʧ��");
			//���ص�ע��ҳ��
			resp.sendRedirect("register.jsp");
			//req.getRequestDispatcher("register.jsp").forward(req, resp);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
