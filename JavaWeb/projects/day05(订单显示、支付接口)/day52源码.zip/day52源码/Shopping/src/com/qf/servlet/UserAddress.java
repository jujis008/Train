package com.qf.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.Address;
import com.qf.entry.User;
import com.qf.service.UserService;
import com.qf.service.impl.UserServiceImpl;
@WebServlet("/userAddress")
public class UserAddress extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		User user =(User)req.getSession().getAttribute("user");
		String flag = req.getParameter("flag");
		UserService service = new UserServiceImpl();
		if(user!=null){
			if("show".equals(flag)){
				List<Address> list = service.getAddresses(user.getId());
				if(list!=null){
					req.getSession().setAttribute("addList", list);
				}
				resp.sendRedirect("address.jsp");
			}
			if("add".equals(flag)){
				String name = req.getParameter("name");
				String phone = req.getParameter("phone");
				String province = req.getParameter("province");
				String city = req.getParameter("city");
				String district = req.getParameter("district");
				String address = req.getParameter("address");
				String fullAddress = province+":"+city+":"+district+":"+address;
				//��������
				Address addr = new Address(fullAddress,name,phone,user.getId(),1);
				boolean b = service.addAddress(addr);
				if(b){
					System.out.println("���ӳɹ�");
					req.getRequestDispatcher("userAddress?flag=show").forward(req, resp);
				}else{
					System.out.println("��ַ��Ϣ����ʧ��");
				}
			}
		}else{
			System.out.println("���¼ ��½�� �ſ��Բ鿴���˵�ַ��Ϣ");
			resp.sendRedirect("login.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
}
