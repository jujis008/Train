package com.qf.dao;

import java.util.List;

import com.qf.entry.Goods;

public interface GoodsDao {
	boolean add(Goods goods);
	List<Goods> get();
	List<Goods> getByTypeId(String typeId);
	Goods getSingle(String id);
}
