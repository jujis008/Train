package com.qf.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.qf.dao.UserDao;
import com.qf.entry.Address;
import com.qf.entry.User;
import com.qf.utils.DBUtils;

public class UserDaoImpl implements UserDao {
	QueryRunner qr = new QueryRunner(DBUtils.getDataSource());
	@Override
	public boolean add(User user) {
		try {
			String sql = "insert into tb_user(username,password,email,gender,flag,role,code) values(?,?,?,?,?,?,?)";
			int i = qr.update(sql,user.getUsername(),user.getPassword(),user.getEmail(),user.getGender(),user.getFlag(),user.getRole(),user.getCode());
			if(i>0){
				return true;
			}
			return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public boolean active(String email, String code) {
		try {
			int i = qr.update("update tb_user set flag=1 where email=? and code=?",email,code);
			if(i>0){
				return true;
			}
			return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public User get(String username) {
		
		try {
			return qr.query("select * from tb_user where username=? and flag=1", new BeanHandler<User>(User.class),username);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public List<Address> getAddresses(int uid) {
		try {
			String sql = "select * from tb_address where uid=? order by id desc,level asc";
			return qr.query(sql, new BeanListHandler<Address>(Address.class),uid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public boolean addAddress(Address address) {
		try {
			String sql = "insert into tb_address(name,phone,detail,uid,level) values(?,?,?,?,?)";
			int i = qr.update(sql, address.getName(),address.getPhone(),address.getDetail(),address.getUid(),address.getLevel());
			if(i>0){
				return true;
			}else{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public List<User> getUserList() {
		try {
			List<User> list = qr.query("select * from tb_user", new BeanListHandler<User>(User.class));
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public Address getSingleA(int aid) {
		try {
			Address address = qr.query("select * from tb_address where id=?", new BeanHandler<Address>(Address.class),aid);
			return address;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
