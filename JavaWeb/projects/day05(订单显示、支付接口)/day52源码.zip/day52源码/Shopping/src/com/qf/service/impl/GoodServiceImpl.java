package com.qf.service.impl;

import java.util.List;

import com.qf.dao.GoodsDao;
import com.qf.dao.impl.GoodsDaoImpl;
import com.qf.entry.Goods;
import com.qf.service.GoodsService;

public class GoodServiceImpl implements GoodsService {
	GoodsDao dao = new GoodsDaoImpl();
	@Override
	public boolean add(Goods goods) {
		// TODO Auto-generated method stub
		return dao.add(goods);
	}
	@Override
	public List<Goods> get() {
		// TODO Auto-generated method stub
		return dao.get();
	}
	@Override
	public List<Goods> getByTypeId(String typeId) {
		// TODO Auto-generated method stub
		return dao.getByTypeId(typeId);
	}
	@Override
	public Goods getSingle(String id) {
		// TODO Auto-generated method stub
		return dao.getSingle(id);
	}

}
