package com.qf.entry;

public class Goods {
	private int id;
	private int price;
	private int typeid;
	private int star;
	private String name;
	private String picture;
	private String intro;
	private String pubdate;
	private String typeName;
	
	public Goods() {
		super();
	}
	public Goods(int id, int price, int typeid, int star, String name, String picture, String intro, String pubdate
			) {
		super();
		this.id = id;
		this.price = price;
		this.typeid = typeid;
		this.star = star;
		this.name = name;
		this.picture = picture;
		this.intro = intro;
		this.pubdate = pubdate;
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getTypeid() {
		return typeid;
	}
	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}
	public int getStar() {
		return star;
	}
	public void setStar(int star) {
		this.star = star;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public String getIntro() {
		return intro;
	}
	public void setIntro(String intro) {
		this.intro = intro;
	}
	public String getPubdate() {
		return pubdate;
	}
	public void setPubdate(String pubdate) {
		this.pubdate = pubdate;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	@Override
	public String toString() {
		return "Goods [id=" + id + ", price=" + price + ", typeid=" + typeid + ", star=" + star + ", name=" + name
				+ ", picture=" + picture + ", intro=" + intro + ", pubdate=" + pubdate + ", typeName=" + typeName + "]";
	}
	
}
