package com.qf.service.impl;

import java.util.List;

import com.qf.dao.OrderDao;
import com.qf.dao.impl.OrderDaoImpl;
import com.qf.entry.BuyGoods;
import com.qf.entry.Order;
import com.qf.service.OrderService;

public class OrderServiceImpl implements OrderService {
	OrderDao dao = new OrderDaoImpl();
	@Override
	public boolean add(Order order, List<BuyGoods> list) {
		// TODO Auto-generated method stub
		return dao.add(order, list);
	}
	@Override
	public List<Order> getAll(int uid) {
		// TODO Auto-generated method stub
		return dao.getAll(uid);
	}
	@Override
	public Order getSingle(String oid) {
		// TODO Auto-generated method stub
		return dao.getSingle(oid);
	}
	@Override
	public List<BuyGoods> getDetail(String oid) {
		// TODO Auto-generated method stub
		return dao.getDetail(oid);
	}
	@Override
	public boolean changeOrderState(String oid) {
		// TODO Auto-generated method stub
		return dao.changeOrderState(oid);
	}

}
