package com.qf.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.Cart;
import com.qf.entry.User;
import com.qf.service.CartService;
import com.qf.service.impl.CartServiceImpl;
import com.qf.utils.StrUtils;
//�޸Ĺ��ﳵ���� �޸� �� ɾ�� �������
@WebServlet("/updateCartNum")
public class UpdateCartNum extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User user = (User)req.getSession().getAttribute("user");
		String id = req.getParameter("id");
		String num = req.getParameter("num");
		String price = req.getParameter("price");
		if(StrUtils.empty(id,price,num)){
			CartService service = new CartServiceImpl();
			int n = Integer.parseInt(num);
			if(n!=0){//�޸�
				System.out.println(id+"..."+price+"..."+num);
				service.update(new Cart(user.getId(),Integer.parseInt(id),n,Integer.parseInt(price)));
			}else{//ɾ��
				service.delete(user.getId(),Integer.parseInt(id));
			}
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
