package com.qf.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;

import com.qf.dao.CartDao;
import com.qf.entry.BuyGoods;
import com.qf.entry.Cart;
import com.qf.entry.Goods;
import com.qf.utils.DBUtils;

public class CartDaoImpl implements CartDao{
	QueryRunner qr = new QueryRunner(DBUtils.getDataSource());
	@Override
	public boolean add(Cart cart) {
		//���ӹ��ﳵ ��Ϊ�������
		//1.��һ������ insert
		//2.���Ӷ�θ���Ʒ update ����+1 ��Ǯ ԭ�б��еļ۸� + �µļ۸�
		//�Ȳ�ѯtb_cart���� �Ƿ��Ѿ��и�����¼
		try {
			int i=0;
			Cart c = qr.query("select * from tb_cart where id=? and pid=?", new BeanHandler<Cart>(Cart.class),cart.getUid(),cart.getPid());
			if(c==null){//����
				i = qr.update("insert into tb_cart(id,pid,num,money) values(?,?,?,?)",new Object[]{cart.getUid(),cart.getPid(),cart.getNum(),cart.getMoney()});
			}else{//�޸�
				i = qr.update("update tb_cart set num=num+1,money=? where id=? and pid=?",c.getMoney()+cart.getMoney(),cart.getUid(),cart.getPid());
			}
			if(i>0){
				return true;
			}else{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	//��ѯָ���û��Ĺ��ﳵ��Ϣ
	@Override
	public List<BuyGoods> getAll(int uid) {
		// TODO Auto-generated method stub
		try {
			String sql="select g.*,c.num,c.money from tb_cart c join tb_goods g on c.pid=g.id where c.id=?";
			
			return qr.query(sql, new ResultSetHandler<List<BuyGoods>>(){

				@Override
				public List<BuyGoods> handle(ResultSet rs) throws SQLException {
					List<BuyGoods> list = new  ArrayList<>();
					while(rs.next()){
						list.add(new BuyGoods(rs.getInt("num"), rs.getInt("money"), 
								new Goods(rs.getInt("id"),rs.getInt("price"),
										rs.getInt("typeid"),rs.getInt("star"),
										rs.getString("name"),rs.getString("picture"),
										rs.getString("intro"),rs.getString("pubdate"))));
					}
					return list;
				}},uid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	//�޸Ĺ��ﳵ��Ʒ���� + - �����Ӹ�������������� ��ȥ �����ľ���ֵ
	@Override
	public boolean update(Cart cart) {
		try {
			int i = qr.update("update tb_cart set num=num+?,money=money+? where id=? and pid=?",
					cart.getNum(),cart.getNum()>0?cart.getMoney():-cart.getMoney(),cart.getUid(),cart.getPid());
			if(i>0){
				return true;
			}else{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public boolean delete(int uid, int pid) {
		
		try {
			//��չ��ﳵ
			String sql="delete from tb_cart where id=? ";
			if(pid>0){// ���Ǵӹ��ﳵ��ɾ����ǰĳһ����Ʒ
				sql+=" and pid="+pid;
			}
			int i = qr.update(sql,uid);
			if(i>0){
				return true;
			}else{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
