package com.qf.service.impl;

import java.util.List;

import com.qf.dao.UserDao;
import com.qf.dao.impl.UserDaoImpl;
import com.qf.entry.Address;
import com.qf.entry.User;
import com.qf.service.UserService;

public class UserServiceImpl implements UserService {
	UserDao dao = new UserDaoImpl();
	@Override
	public boolean add(User user) {
		
		return dao.add(user);
	}
	@Override
	public boolean active(String email, String code) {
		// TODO Auto-generated method stub
		return dao.active(email,code);
	}
	@Override
	public User get(String username) {
		// TODO Auto-generated method stub
		return dao.get(username);
	}
	@Override
	public List<Address> getAddresses(int uid) {
		// TODO Auto-generated method stub
		return dao.getAddresses(uid);
	}
	@Override
	public boolean addAddress(Address address) {
		// TODO Auto-generated method stub
		return dao.addAddress(address);
	}
	@Override
	public List<User> getUserList() {
		// TODO Auto-generated method stub
		return dao.getUserList();
	}
	@Override
	public Address getSingleA(int aid) {
		// TODO Auto-generated method stub
		return dao.getSingleA(aid);
	}

}
