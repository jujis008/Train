package com.qf.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.Goods;
import com.qf.service.GoodsService;
import com.qf.service.impl.GoodServiceImpl;

@WebServlet("/getGoodsById")
public class GetGoodsById extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		if(id!=null){
			GoodsService service = new GoodServiceImpl();
			Goods good = service.getSingle(id);
			req.setAttribute("good", good);
			req.getRequestDispatcher("bookDetail.jsp").forward(req, resp);
		}else{
			System.out.println("idΪ��");
		}
		
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
