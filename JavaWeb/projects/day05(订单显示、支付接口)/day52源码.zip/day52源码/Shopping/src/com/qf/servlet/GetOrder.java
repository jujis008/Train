package com.qf.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.Order;
import com.qf.entry.User;
import com.qf.service.impl.OrderServiceImpl;
//��ȡ��ǰ�û��Ķ�����Ϣ�б�
@WebServlet("/getOrder")
public class GetOrder extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User user = (User)req.getSession().getAttribute("user");
		if(user!=null){
			//�����û�id ��ѯOrder�� ����list����
			List<Order> list = new OrderServiceImpl().getAll(user.getId());
			req.setAttribute("orders", list);
			req.getRequestDispatcher("orderList.jsp").forward(req, resp);
		}else{
			resp.sendRedirect("login.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
