package com.qf.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.Address;
import com.qf.entry.BuyGoods;
import com.qf.entry.User;
import com.qf.service.impl.CartServiceImpl;
import com.qf.service.impl.UserServiceImpl;
//��ȡ����Ԥ����Ϣ
@WebServlet("/getOrderView")
public class GetOrderView extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User user = (User)req.getSession().getAttribute("user");
		if(user!=null){
			
		//����User id ��ȡ��ַ��Ϣ
		List<Address> as = new UserServiceImpl().getAddresses(user.getId());
		//��ȡָ���û��Ĺ��ﳵ��Ϣ
		List<BuyGoods> list = new CartServiceImpl().getAll(user.getId());
		
		req.setAttribute("list", list);
		req.setAttribute("as", as);
		req.getRequestDispatcher("order.jsp").forward(req, resp);
		}else{
			resp.sendRedirect("login.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
