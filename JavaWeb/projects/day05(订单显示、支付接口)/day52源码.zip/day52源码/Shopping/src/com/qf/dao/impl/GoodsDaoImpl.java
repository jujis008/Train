package com.qf.dao.impl;

import java.util.Date;
import java.util.List;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.qf.dao.GoodsDao;
import com.qf.entry.Goods;
import com.qf.utils.DBUtils;

public class GoodsDaoImpl implements GoodsDao{
	QueryRunner qr = new QueryRunner(DBUtils.getDataSource());
	@Override
	public boolean add(Goods goods) {
		
		try {
			String d = goods.getPubdate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse(d);
			String sql = "insert into tb_goods(name,pubdate,picture,price,star,intro,typeid) values(?,?,?,?,?,?,?)";
			int i = qr.update(sql,
			goods.getName(),new java.sql.Date(date.getTime()),
			goods.getPicture(),goods.getPrice(),
			goods.getStar(),goods.getIntro(),goods.getTypeid());
			if(i>0){
				return true;
			}else{
				return false;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public List<Goods> get() {
		try {
			List<Goods> list = qr.query("select g.*,gt.name typeName from tb_goods g join tb_goods_type gt on g.typeid = gt.id", new BeanListHandler<Goods>(Goods.class));
			if(list!=null){
				return list;
			}else{
				return null;
			}			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	//���� ��Ʒ���� ��ѯ��Ʒ�б�
	@Override
	public List<Goods> getByTypeId(String typeId) {
		List<Goods> list;
		try {
			list = qr.query("select g.*,gt.name typeName from tb_goods g join tb_goods_type gt on g.typeid = gt.id where typeid=?", new BeanListHandler<Goods>(Goods.class),Integer.parseInt(typeId));
			if(list!=null){
				return list;
			}else{
				return null;
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	@Override
	public Goods getSingle(String id) {
		try {
			Goods good = qr.query("select * from tb_goods where id=?", new BeanHandler<Goods>(Goods.class),Integer.parseInt(id));
			return good;
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
