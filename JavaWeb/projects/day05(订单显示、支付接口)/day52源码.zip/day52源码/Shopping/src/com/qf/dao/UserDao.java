package com.qf.dao;

import java.util.List;

import com.qf.entry.Address;
import com.qf.entry.User;

public interface UserDao {
	public boolean add(User user);
	public boolean active(String email,String code);
	public User get(String username);
	public List<Address> getAddresses(int uid);
	public boolean addAddress(Address address);
	List<User> getUserList();
	Address getSingleA(int aid);
}
