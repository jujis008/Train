package com.qf.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.Cart;
import com.qf.entry.User;
import com.qf.service.CartService;
import com.qf.service.impl.CartServiceImpl;
import com.qf.utils.StrUtils;
@WebServlet("/addCart")
public class AddCart extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//��ȡsession�е�user���� ���ж��Ƿ��¼
		//���û�е�¼ ����ת����¼ҳ��
		User user = (User)req.getSession().getAttribute("user");
		if(user!=null){
			String id =req.getParameter("id");//��Ʒid
			String price = req.getParameter("price");//��Ʒ�۸�
			//���ù����� �ж� ����������Ƿ�Ϊ��
			if(StrUtils.empty(id,price)){
				CartService service = new CartServiceImpl();
				if(service.add(new Cart(user.getId(),Integer.parseInt(id),1,Integer.parseInt(price)))){
					//���ӳɹ�
					resp.sendRedirect("cartSuccess.jsp");
				}
			}else{
				resp.sendRedirect("getBookListByTypeId?typeId=1");
			}
		}else{
			resp.sendRedirect("login.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
