$(function () {
  $('#distpicker').distpicker({
    autoSelect: false
  });

});
