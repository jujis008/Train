/*��������ģʽ
	��Ʒ ���� name ���� count
	������
	������
*/
class Demo_2 
{
	public static void main(String[] args) 
	{
		Resource r = new Resource();
		Producer p = new Producer(r);
		Consumer c = new Consumer(r);
		Thread t1 = new Thread(p);
		Thread t2 = new Thread(p);

		Thread t3 = new Thread(c);
		Thread t4 = new Thread(c);
		t1.start();
		t2.start();

		t3.start();
		t4.start();
	}
}
/*
Thread-1..make..+��Ʒ+--55
Thread-2..make..+��Ʒ+--56
Thread-3..shopping..+��Ʒ+--56
*/
class Resource
{
	private String name;
	private int count = 1;
	private boolean flag = false;

	public synchronized void set(String name){ //t1 t2
		while(flag){
			try{
				this.wait(); //t1 �����ʸ� t2��ȡ�ʸ� ��һ��������cpu
			}catch(Exception e){}
		}
		this.name = name + "--" + count++;
		System.out.println(Thread.currentThread().getName()+"..make.."+this.name);
		
		flag = true;	
		this.notifyAll();	// t1 ���� �� t2 ���ʸ�
		
	}
	public synchronized void out(){ // t3 t4
		while(!flag){
			try{
				this.wait(); //t3 �����ʸ� t4�����ʸ�
			}catch(Exception e){}
		}
		System.out.println(Thread.currentThread().getName()+"..shopping.."+this.name);
		flag = false;
		this.notifyAll(); 
	}
}
class Producer implements Runnable
{
	private Resource res;
	public Producer(Resource res){
		this.res = res;
	}
	public void run(){
		while(true){
			res.set("+��Ʒ+");
		}
	}
}
class Consumer implements Runnable
{
	private Resource res;
	public Consumer(Resource res){
		this.res = res;
	}
	public void run(){
		while(true){
			res.out();
		}
	}
}